from django.shortcuts import render
# Create your views here

def contact_views(request):
  return render(request, "contact/template_contact.html")
