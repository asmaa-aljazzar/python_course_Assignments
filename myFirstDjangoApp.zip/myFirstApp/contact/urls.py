# Define a URL route for contact app
from django.urls import path
from . import views

urlpatterns = [
  path ('', views.contact_views, name='contact_views') ## go to views.py and create a function called email
]